import sys
# run tis as follows:
# python using_sysargs.py athlone ie

print(sys.argv[1], sys.argv[2])