import sys


sys.stdout.write('wow') 