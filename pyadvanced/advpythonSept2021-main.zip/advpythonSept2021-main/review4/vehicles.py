# Vehicles class
from swapi import Swapi

class Vehicles(Swapi):
    @property # type props then press tab
    def height(self):
        return
    @height.setter
    def height(self, value):
        pass