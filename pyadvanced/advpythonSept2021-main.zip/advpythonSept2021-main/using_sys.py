# you can find the capabilities of the current platform
import sys
print(sys.path)
print(sys.version)
print(sys.version_info)
print(sys.platform)
print(sys.base_prefix)