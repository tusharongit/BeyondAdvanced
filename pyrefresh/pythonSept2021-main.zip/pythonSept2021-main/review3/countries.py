# a set (could use a tuple)
countries = {'ie', 'uk', 'fr', 'aus', 'tw', 'jm'}