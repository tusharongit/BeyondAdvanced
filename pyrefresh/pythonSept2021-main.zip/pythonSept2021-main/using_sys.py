import sys # sys is part of the standard Python library

print(sys.version)

print(sys.maxsize) # size of biggest objet possible on current platform

print(sys.path) # where python looks for imports

print(sys.float_info) # floating point number info

